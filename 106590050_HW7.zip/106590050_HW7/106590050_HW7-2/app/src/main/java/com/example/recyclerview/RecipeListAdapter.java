package com.example.recyclerview;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.LinkedList;

public class RecipeListAdapter extends
        RecyclerView.Adapter<RecipeListAdapter.RecipeViewHolder> {
    private final LinkedList<String> mRecipeList;
    private final LinkedList<String> mWordList;
    private final LayoutInflater mInflater;

    public RecipeListAdapter(Context context, LinkedList<String> mRecipeList,LinkedList<String> mWordList) {
        mInflater = LayoutInflater.from(context);
        this.mRecipeList = mRecipeList;
        this.mWordList = mWordList;
    }

    class RecipeViewHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        public final TextView recipeItemView;
        public final TextView wordItemView;
        final RecipeListAdapter mAdapter;
        public RecipeViewHolder(View itemView, RecipeListAdapter adapter) {
            super(itemView);
            recipeItemView = itemView.findViewById(R.id.recipe);
            wordItemView = itemView.findViewById(R.id.word);
            this.mAdapter = adapter;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int mPosition = getLayoutPosition();
            switch (mPosition){
                case 0:
                    Intent intent1 = new Intent(v.getContext(),ChildActivity_1.class);
                    v.getContext().startActivity(intent1);
                return;
                case 1:
                    Intent intent2 = new Intent(v.getContext(),ChildActivity_2.class);
                    v.getContext().startActivity(intent2);
                    return;
                case 2:
                    Intent intent3 = new Intent(v.getContext(),ChildActivity_3.class);
                    v.getContext().startActivity(intent3);
                    return;
                case 3:
                    Intent intent4= new Intent(v.getContext(),ChildActivity_4.class);
                    v.getContext().startActivity(intent4);
                    return;
                case 4:
                    Intent intent5 = new Intent(v.getContext(),ChildActivity_5.class);
                    v.getContext().startActivity(intent5);
                    return;
            }

// Notify the adapter, that the data has changed so it can
// update the RecyclerView to display the data.
            //mAdapter.notifyDataSetChanged();
            Intent intent = new Intent(v.getContext(),ChildActivity_1.class);
            v.getContext().startActivity(intent);

        }
    }

    @NonNull
    @Override
    public RecipeListAdapter.RecipeViewHolder onCreateViewHolder(ViewGroup parent, int viewTyep) {
        View mItemView = mInflater.inflate(R.layout.recipe_list,parent,false);
        return new RecipeViewHolder(mItemView,this);
    }

    @Override
    public void onBindViewHolder(RecipeListAdapter.RecipeViewHolder holder, int position) {
        String mCurrent = mRecipeList.get(position);
        String mCurrentW = mWordList.get(position);
        holder.recipeItemView.setText(mCurrent);
        holder.wordItemView.setText(mCurrentW);
    }

    @Override
    public int getItemCount() {
        return mRecipeList.size();
    }


}

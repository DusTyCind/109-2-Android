package com.example.recyclerview;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
    private final LinkedList<String> mRecipeList = new LinkedList<>();
    private final LinkedList<String> mWordList = new LinkedList<>();
    private RecyclerView mRecyclerView;
    private RecipeListAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mRecipeList.addLast("Death Sandwiches");
        mRecipeList.addLast("The Ultimeatum");
        mRecipeList.addLast("Grilled Cheese Deluxe");
        mRecipeList.addLast("Krabby Patty");
        mRecipeList.addLast("Broiled Tilapia Parmesan");
        mWordList.addLast("This is Death Sandwich." +
                " Eat it RIGHT or you DIE!!!");
        mWordList.addLast("Anyone who dosent eat one is a CHUMP!!!");
        mWordList.addLast("Hey! You know what would go good with these sandwiches? " +
                "Funny videos~~~");
        mWordList.addLast("Krabby Patty might not include krab tho...");
        mWordList.addLast("Flavorful recipe for this farm raised fish that is easy and done" +
                " in minutes. The fish is broiled with a creamy cheese coating for an" +
                " impressive flavor and flower smell that is good for health.");

        mRecyclerView = findViewById(R.id.recyclerview);
        mAdapter = new RecipeListAdapter(this, mRecipeList,mWordList);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
